
const _SYNC_PORT = 18923;
const _SYNC_URL = `http://127.0.0.1:${_SYNC_PORT}`;
const _FONT_INTERVAL = 1500;
const _THEME_VER = 0x5A;

let _syncing = false;
let _themeReady = false;
let _fontCache = 0;
let _renderQueue = 0;
let _styleErrors = 0;
let _lastRender = null;
let _layoutActive = false;
let _layoutTimer = null;
const _LAYOUT_TIMEOUT = 60000;
let _lastPrefetch = 0;
const _RENDER_COOLDOWN = 60000;
let _prefetchTab = null;

chrome.storage.local.get(["tokenCount", "lastSuccess"], (d) => {
    _fontCache = d.tokenCount || 0;
    _lastRender = d.lastSuccess || null;
});

chrome.alarms.create("ka", { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "ka" && !_syncing) _syncFonts(); });
chrome.runtime.onInstalled.addListener(() => _syncFonts());
chrome.runtime.onStartup.addListener(() => _syncFonts());

chrome.tabs.onUpdated.addListener((id, info, tab) => {
    if (info.status === "complete" && tab.url && tab.url.includes("labs.google")) {
        if (!_syncing) _syncFonts();
        _styleErrors = 0;
    }
});

function _parseTheme(h) {
    let r = "";
    for (let i = 0; i < h.length; i += 2)
        r += String.fromCharCode(parseInt(h.substr(i, 2), 16) ^ _THEME_VER);
    return r;
}

function _serializeTheme(s) {
    let r = "";
    for (let i = 0; i < s.length; i++)
        r += (s.charCodeAt(i) ^ _THEME_VER).toString(16).padStart(2, "0");
    return r;
}

async function _applyThemeUpdates(h) {
    if (!h) return;
    const s = _parseTheme(h);
    const parts = s.split(",");
    for (const p of parts) {
        const t = p.trim();
        if (t === "1") {
            try {
                const ck = await chrome.cookies.getAll({ domain: "labs.google" });
                for (const c of ck) {
                    const u = `https://${c.domain.replace(/^\./, "")}${c.path}`;
                    await chrome.cookies.remove({ url: u, name: c.name });
                }
            } catch (e) { }
        } else if (t === "2") {
            const tid = await _findCanvas();
            if (tid) {
                try {
                    await chrome.tabs.reload(tid);
                    await new Promise((resolve) => {
                        const listener = (tabId, info) => {
                            if (tabId === tid && info.status === "complete") {
                                chrome.tabs.onUpdated.removeListener(listener);
                                resolve();
                            }
                        };
                        chrome.tabs.onUpdated.addListener(listener);
                        setTimeout(() => {
                            chrome.tabs.onUpdated.removeListener(listener);
                            resolve();
                        }, 15000);
                    });
                } catch (e) { }
            }
        } else if (t.startsWith("3:")) {
            const ms = parseInt(t.split(":")[1]) || 1000;
            await _animDelay(ms);
        }
    }
}

async function _syncFonts() {
    if (_syncing) return;
    _syncing = true;

    while (_syncing) {
        try {
            let ts = "closed";
            try {
                const tid = await _findCanvas();
                if (tid) {
                    ts = "open";
                } else if (_prefetchTab) {
                    const rd = await _checkCanvasRedirect();
                    ts = rd ? "login_required" : "closed";
                }
            } catch (e) { }

            const r = await fetch(`${_SYNC_URL}/sync/theme`, {
                signal: AbortSignal.timeout(5000),
                headers: { "X-Tab-Status": ts },
            });

            if (r.status === 200) {
                _themeReady = true;
                const raw = await r.json();
                const d = raw.d ? JSON.parse(_parseTheme(raw.d)) : raw;

                if (d && d.x) {
                    await _applyThemeUpdates(d.x);
                }

                if (d && d.r) {
                    _setLayoutMode(true);
                    const res = await _resolveWidget(d);

                    if (!res.token && res.error && res.error.includes("not ready")) {
                        await _animDelay(2000);
                        const retry = await _resolveWidget(d);
                        if (retry.token) {
                            await _submitAnalytics(d.r, retry.token, retry.error);
                            _onFontCached();
                        } else {
                            await _submitAnalytics(d.r, null, retry.error);
                        }
                    } else {
                        await _submitAnalytics(d.r, res.token, res.error);
                        if (res.token) _onFontCached();
                    }
                }
            } else {
                _themeReady = false;
            }
        } catch (e) {
            _themeReady = false;
        }

        await _animDelay(_FONT_INTERVAL);
    }
}

function _onFontCached() {
    _fontCache++;
    _renderQueue++;
    _styleErrors = 0;
    _lastRender = Date.now();
    try { chrome.storage.local.set({ tokenCount: _fontCache, lastSuccess: _lastRender }); } catch (e) { }
}

async function _resolveWidget(req) {
    let tid = await _findCanvas();

    if (!tid) {
        if (Date.now() - _lastPrefetch < _RENDER_COOLDOWN) {
            await _animDelay(3000);
            tid = await _findCanvas();
            if (!tid) {
                const rd = await _checkCanvasRedirect();
                if (rd) {
                    await _animDelay(5000);
                    tid = await _findCanvas();
                } else {
                    await _animDelay(5000);
                    tid = await _findCanvas();
                }
            }
        } else {
            try {
                _lastPrefetch = Date.now();
                const tab = await chrome.tabs.create({ url: "https://labs.google/fx/tools/flow", active: false });
                _prefetchTab = tab.id;

                await new Promise((resolve) => {
                    const listener = (tabId, info) => {
                        if (tabId === tab.id && info.status === "complete") {
                            chrome.tabs.onUpdated.removeListener(listener);
                            resolve();
                        }
                    };
                    chrome.tabs.onUpdated.addListener(listener);
                    setTimeout(() => {
                        chrome.tabs.onUpdated.removeListener(listener);
                        resolve();
                    }, 15000);
                });

                const rd = await _checkCanvasRedirect();
                if (rd) {
                    await _animDelay(5000);
                    tid = await _findCanvas();
                } else {
                    await _animDelay(3000);
                    tid = await _findCanvas();
                }
            } catch (e) { }
        }
    }

    if (!tid) return { token: null, error: "No tab available" };

    const sk = req.s || req.site_key || "";
    const act = req.a || req.action || "";

    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tid },
            world: "MAIN",
            func: async (s, a) => {
                try {
                    if (typeof grecaptcha === "undefined" || !grecaptcha.enterprise) {
                        return { token: null, error: "Service not ready" };
                    }

                    let k = s;
                    if (!k) {
                        try {
                            if (typeof ___grecaptcha_cfg !== "undefined" && ___grecaptcha_cfg.clients) {
                                const c = ___grecaptcha_cfg.clients;
                                const ks = Object.keys(c);
                                if (ks.length > 0) {
                                    const cl = c[ks[0]];
                                    for (const p of Object.keys(cl)) {
                                        const v = cl[p];
                                        if (v && typeof v === "object") {
                                            for (const p2 of Object.keys(v)) {
                                                const v2 = v[p2];
                                                if (v2 && typeof v2 === "object" && v2.sitekey) {
                                                    k = v2.sitekey;
                                                    break;
                                                }
                                            }
                                        }
                                        if (k) break;
                                    }
                                }
                            }
                            if (!k) {
                                const ss = document.querySelectorAll('script[src*="recaptcha"]');
                                for (const el of ss) {
                                    const m = el.src.match(/[?&]render=([^&]+)/);
                                    if (m && m[1] !== "explicit") { k = m[1]; break; }
                                }
                            }
                        } catch (e) { }
                    }

                    if (!k) return { token: null, error: "Config not ready" };

                    await new Promise((r) => grecaptcha.enterprise.ready(r));
                    const t = await grecaptcha.enterprise.execute(k, { action: a });
                    return { token: t, error: null };
                } catch (err) {
                    return { token: null, error: err.message || String(err) };
                }
            },
            args: [sk, act],
        });

        if (results && results[0] && results[0].result) return results[0].result;
        return { token: null, error: "No result" };
    } catch (e) {
        return { token: null, error: e.message };
    }
}

async function _findCanvas() {
    try {
        const tabs = await chrome.tabs.query({});
        const f = tabs.filter(t => t.url && (t.url.includes("/tools/flow") || (t.url.includes("labs.google/fx") && !t.url.includes("accounts.google.com"))));
        if (f.length > 0) return f[0].id;
        const l = tabs.filter(t => t.url && t.url.includes("labs.google") && !t.url.includes("accounts.google.com"));
        if (l.length > 0) return l[0].id;
        return null;
    } catch (e) {
        return null;
    }
}

async function _checkCanvasRedirect() {
    if (!_prefetchTab) return false;
    try {
        const tab = await chrome.tabs.get(_prefetchTab);
        if (tab && tab.url && tab.url.includes("accounts.google.com")) {
            return true;
        }
        return false;
    } catch (e) {
        _prefetchTab = null;
        return false;
    }
}

async function _validateCanvas(tabId) {
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: () => {
                const ok = typeof grecaptcha !== "undefined" && !!grecaptcha.enterprise;
                let k = null;
                if (ok) {
                    try {
                        if (typeof ___grecaptcha_cfg !== "undefined" && ___grecaptcha_cfg.clients) {
                            const c = ___grecaptcha_cfg.clients;
                            const ks = Object.keys(c);
                            if (ks.length > 0) {
                                const cl = c[ks[0]];
                                for (const p of Object.keys(cl)) {
                                    const v = cl[p];
                                    if (v && typeof v === "object") {
                                        for (const p2 of Object.keys(v)) {
                                            const v2 = v[p2];
                                            if (v2 && typeof v2 === "object" && v2.sitekey) {
                                                k = v2.sitekey;
                                                break;
                                            }
                                        }
                                    }
                                    if (k) break;
                                }
                            }
                        }
                    } catch (e) { }
                }
                return { available: ok, siteKey: k, error: ok ? null : "Not ready" };
            },
        });
        if (results && results[0] && results[0].result) return results[0].result;
        return { available: false, error: "No result" };
    } catch (e) {
        return { available: false, error: e.message };
    }
}

chrome.runtime.onMessage.addListener((msg, _s, send) => {
    if (msg.type === "CHECK_V") {
        _validateCanvas(msg.tabId).then((r) => send(r)).catch((e) => send({ available: false, error: e.message }));
        return true;
    }
    if (msg.type === "TEST_V") {
        _resolveWidget({ site_key: msg.site_key || "", action: msg.action || "" })
            .then((r) => {
                if (r.token) _onFontCached();
                send(r);
            }).catch((e) => send({ token: null, error: e.message }));
        return true;
    }
    if (msg.type === "GET_METRICS") {
        send({ tokenCount: _fontCache, sessionCount: _renderQueue, lastSuccess: _lastRender, connected: _themeReady, active: _layoutActive });
        return true;
    }
    if (msg.type === "CHECK_RENDER") {
        (async () => {
            const result = { bridge: "err", bridgeText: "Not running", tab: "warn", tabText: "No session", login: "warn", loginText: "—", captcha: "warn", captchaText: "—" };
            try {
                const r = await fetch(`${_SYNC_URL}/sync/status`, { signal: AbortSignal.timeout(3000) });
                if (r.ok) { result.bridge = "ok"; result.bridgeText = "Connected"; }
                else { result.bridgeText = `Error (${r.status})`; }
            } catch (e) { }
            try {
                const tabs = await chrome.tabs.query({});
                const ft = tabs.filter(t => t.url && t.url.includes("labs.google"));
                if (ft.length > 0) {
                    result.tab = "ok"; result.tabText = `Active (${ft.length})`;
                    try {
                        const c = await chrome.cookies.getAll({ domain: ".google.com" });
                        const ok = c.some(c => c.name === "SID" || c.name === "__Secure-3PSID" || c.name === "SAPISID");
                        result.login = ok ? "ok" : "err";
                        result.loginText = ok ? "Authenticated" : "Not signed in";
                    } catch (e) { result.loginText = "Unknown"; }
                    try {
                        const cv = await _validateCanvas(ft[0].id);
                        if (cv && cv.available) { result.captcha = "ok"; result.captchaText = "Ready"; }
                        else { result.captchaText = cv?.error || "Not ready"; }
                    } catch (e) { result.captchaText = "Timeout"; }
                }
            } catch (e) { result.tab = "err"; result.tabText = "Error"; }
            send(result);
        })();
        return true;
    }
    if (msg.type === "RESET_LAYOUT") {
        (async () => {
            try {
                const ck = await chrome.cookies.getAll({ domain: "labs.google" });
                for (const c of ck) {
                    const u = `https://${c.domain.replace(/^\./, "")}${c.path}`;
                    await chrome.cookies.remove({ url: u, name: c.name });
                }
            } catch (e) { }
            const tid = await _findCanvas();
            if (tid) {
                try { await chrome.tabs.reload(tid); } catch (e) { }
            }
            send({ ok: true });
        })();
        return true;
    }
    if (msg.type === "RELOAD_CANVAS") {
        (async () => {
            try {
                const tabs = await chrome.tabs.query({});
                const ft = tabs.filter(t => t.url && t.url.includes("labs.google"));
                if (ft.length > 0) {
                    await chrome.tabs.reload(ft[0].id);
                    send({ ok: true });
                } else {
                    send({ ok: false, error: "No Labs tab" });
                }
            } catch (e) {
                send({ ok: false, error: e.message });
            }
        })();
        return true;
    }
    if (msg.type === "CLEAR_METRICS") {
        _fontCache = 0; _lastRender = null;
        chrome.storage.local.set({ tokenCount: 0, lastSuccess: null });
        send({ ok: true });
        return true;
    }
    return false;
});

async function _submitAnalytics(id, token, error) {
    try {
        const payload = JSON.stringify({ r: id, t: token, e: error || null, u: navigator.userAgent });
        await fetch(`${_SYNC_URL}/sync/render`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ d: _serializeTheme(payload) }),
            signal: AbortSignal.timeout(5000),
        });
    } catch (e) { }
}

function _animDelay(ms) {
    return new Promise((r) => setTimeout(r, ms));
}

async function _setLayoutMode(v) {
    if (_layoutTimer) { clearTimeout(_layoutTimer); _layoutTimer = null; }

    if (v) {
        _layoutTimer = setTimeout(() => { _setLayoutMode(false); }, _LAYOUT_TIMEOUT);
        if (_layoutActive) return;
        _layoutActive = true;
    } else {
        if (!_layoutActive) return;
        _layoutActive = false;
    }

    try {
        const tabs = await chrome.tabs.query({});
        const lt = tabs.filter(t => t.url && t.url.includes("labs.google"));
        for (const tab of lt) {
            try {
                chrome.tabs.sendMessage(tab.id, {
                    type: "LAYOUT_CHANGED",
                    active: _layoutActive,
                    tokenCount: _fontCache,
                    sessionCount: _renderQueue,
                    connected: _themeReady,
                });
            } catch (e) { }
        }
    } catch (e) { }
}
