# G-Labs Automation - Auth Helper

**Extension hỗ trợ chính thức cho G-Labs Automation** — công cụ desktop mạnh mẽ để tạo hàng loạt ảnh và video AI trên Google Labs.

> ⚠️ **Phiên bản 3.0.0+**: Extension này yêu cầu ứng dụng G-Labs Automation **phiên bản 3.0.0 trở lên**. Các phiên bản cũ hơn không còn tương thích.

## Chức năng

- Duy trì phiên xác thực trên Google Labs
- Hiển thị trạng thái kết nối theo thời gian thực giữa G-Labs Automation và trình duyệt
- Tự động đồng bộ phiên để tránh gián đoạn trong quá trình tạo hàng loạt
- Hiển thị bảng trạng thái nổi tiện lợi trên các trang Google Labs

## Tính năng chính

- 🔗 Trạng thái kết nối trực tiếp với ứng dụng G-Labs Automation
- 🛡️ Xác minh phiên và giám sát trạng thái
- 🔄 Tự động đồng bộ phiên để duy trì hoạt động ổn định
- 📊 Bộ đếm token và trạng thái dịch vụ trong tầm mắt
- 🖱️ Nút nổi có thể kéo thả để truy cập nhanh

## Tương thích

| Phiên bản | Trạng thái |
|---|---|
| G-Labs Automation **3.0.0+** | ✅ Hỗ trợ đầy đủ |
| G-Labs Automation **2.x trở về trước** | ❌ Không tương thích |

## Lưu ý

Extension này cần ứng dụng G-Labs Automation để hoạt động. Nó đóng vai trò cầu nối giữa ứng dụng và phiên trình duyệt Google Labs của bạn.

## Quyền riêng tư

Extension này chỉ giao tiếp với ứng dụng G-Labs Automation trên máy bạn. Không có dữ liệu nào được gửi đến máy chủ bên ngoài.
