# G-Labs Automation - Auth Helper

**Official companion extension for G-Labs Automation** — the powerful desktop tool for batch AI image and video generation on Google Labs.

> ⚠️ **Version 3.0.0+**: This extension requires G-Labs Automation desktop app **version 3.0.0 or later**. Older versions of the desktop app are no longer compatible.

## What it does

- Maintains active authentication sessions on Google Labs
- Provides real-time connection status between G-Labs Automation and your browser
- Synchronizes session state to prevent interruptions during long batch operations
- Displays a convenient floating status panel on Google Labs pages

## Key Features

- 🔗 Live bridge status with the G-Labs Automation desktop app
- 🛡️ Session verification and health monitoring
- 🔄 Automatic session sync to keep operations running smoothly
- 📊 Token counter and service status at a glance
- 🖱️ Draggable floating action button for quick access

## Compatibility

| Version | Status |
|---|---|
| G-Labs Automation **3.0.0+** | ✅ Fully supported |
| G-Labs Automation **2.x and older** | ❌ Not compatible |

## Note

This extension requires the G-Labs Automation desktop application to function. It acts as a bridge between the app and your Google Labs browser session.

## Privacy

This extension only communicates with your local G-Labs Automation instance. No data is sent to external servers.
