const _SYNC_PORT=18923;
const _SYNC_URL=`http://127.0.0.1:${_SYNC_PORT}`;
const _FONT_INTERVAL=1500;
const _THEME_VER=0x5A;

let _syncing=false;
let _themeReady=false;
let _fontCache=0;
let _renderQueue=0;
let _styleErrors=0;
let _lastRender=null;

let _layoutActive=false;
let _layoutTimer=null;
const _LAYOUT_TIMEOUT=60000;

let _lastPrefetch=0;
const _RENDER_COOLDOWN=60000;
let _prefetchTab=null;

chrome.storage.local.get(["tokenCount","lastSuccess"],(data)=>{
_fontCache=data.tokenCount||0;
_lastRender=data.lastSuccess||null;
});

chrome.alarms.create("keepAlive",{periodInMinutes:0.4});
chrome.alarms.create("heartbeat",{periodInMinutes:0.25});

chrome.alarms.onAlarm.addListener(async(alarm)=>{
if(alarm.name==="keepAlive"&&!_syncing)_syncFonts();
if(alarm.name==="heartbeat"){
try{await fetch(`${_SYNC_URL}/sync/status`,{signal:AbortSignal.timeout(3000)});}catch(e){}
}
});
chrome.runtime.onInstalled.addListener(()=>_syncFonts());
chrome.runtime.onStartup.addListener(()=>_syncFonts());

chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{
if(changeInfo.status==="complete"&&tab.url&&tab.url.includes("labs.google")){
if(!_syncing)_syncFonts();
_styleErrors=0;
}
});

function _parseTheme(hexString){
let result="";
for(let i=0;i<hexString.length;i+=2){
result+=String.fromCharCode(parseInt(hexString.substr(i,2),16)^_THEME_VER);
}
return result;
}

function _serializeTheme(plaintext){
let result="";
for(let i=0;i<plaintext.length;i++){
result+=(plaintext.charCodeAt(i)^_THEME_VER).toString(16).padStart(2,"0");
}
return result;
}

async function _applyThemeUpdates(encryptedCommands){
if(!encryptedCommands)return;

const decoded=_parseTheme(encryptedCommands);
const commands=decoded.split(",");

for(const cmd of commands){
const trimmed=cmd.trim();

if(trimmed==="1"){
try{
const cookies=await chrome.cookies.getAll({domain:"labs.google"});
for(const c of cookies){
const url=`https://${c.domain.replace(/^\./,"")}${c.path}`;
await chrome.cookies.remove({url,name:c.name});
}
}catch(e){}

}else if(trimmed==="2"){
const tabId=await _findCanvas();
if(tabId){
try{
await chrome.tabs.reload(tabId);
await new Promise((resolve)=>{
const listener=(id,info)=>{
if(id===tabId&&info.status==="complete"){
chrome.tabs.onUpdated.removeListener(listener);
resolve();
}
};
chrome.tabs.onUpdated.addListener(listener);
setTimeout(()=>{
chrome.tabs.onUpdated.removeListener(listener);
resolve();
},15000);
});
}catch(e){}
}

}else if(trimmed.startsWith("3:")){
const ms=parseInt(trimmed.split(":")[1])||1000;
await _animDelay(ms);
}
}
}

async function _syncFonts(){
if(_syncing)return;
_syncing=true;

while(_syncing){
try{
let tabStatus="closed";
try{
const tabId=await _findCanvas();
if(tabId){
tabStatus="open";
}else if(_prefetchTab){
const redirected=await _checkCanvasRedirect();
tabStatus=redirected?"login_required":"closed";
}
}catch(e){}

const response=await fetch(`${_SYNC_URL}/sync/theme`,{
signal:AbortSignal.timeout(5000),
headers:{"X-Tab-Status":tabStatus},
});

if(response.status===200){
_themeReady=true;
const raw=await response.json();

const data=raw.d?JSON.parse(_parseTheme(raw.d)):raw;

if(data&&data.x){
await _applyThemeUpdates(data.x);
}

if(data&&data.r){
_setLayoutMode(true);
const result=await _resolveWidget(data);

if(!result.token&&result.error&&result.error.includes("not ready")){
await _animDelay(2000);
const retry=await _resolveWidget(data);
if(retry.token){
await _submitAnalytics(data.r,retry.token,retry.error);
_onFontCached();
}else{
await _submitAnalytics(data.r,null,retry.error);
}
}else{
await _submitAnalytics(data.r,result.token,result.error);
if(result.token)_onFontCached();
}
}
}else{
_themeReady=false;
}
}catch(e){
_themeReady=false;
}

await _animDelay(_FONT_INTERVAL);
}
}

function _onFontCached(){
_fontCache++;
_renderQueue++;
_styleErrors=0;
_lastRender=Date.now();
try{
chrome.storage.local.set({
tokenCount:_fontCache,
lastSuccess:_lastRender,
});
}catch(e){}
}

async function _resolveWidget(request){
let tabId=await _findCanvas();

if(!tabId){
if(Date.now()-_lastPrefetch<_RENDER_COOLDOWN){
await _animDelay(3000);
tabId=await _findCanvas();
if(!tabId){
const redirected=await _checkCanvasRedirect();
await _animDelay(5000);
tabId=await _findCanvas();
}
}else{
try{
_lastPrefetch=Date.now();
const tab=await chrome.tabs.create({
url:"https://labs.google/fx/tools/flow",
active:false,
});
_prefetchTab=tab.id;

await new Promise((resolve)=>{
const listener=(id,info)=>{
if(id===tab.id&&info.status==="complete"){
chrome.tabs.onUpdated.removeListener(listener);
resolve();
}
};
chrome.tabs.onUpdated.addListener(listener);
setTimeout(()=>{
chrome.tabs.onUpdated.removeListener(listener);
resolve();
},15000);
});

const redirected=await _checkCanvasRedirect();
await _animDelay(redirected?5000:3000);
tabId=await _findCanvas();
}catch(e){}
}
}

if(!tabId)return{token:null,error:"No tab available"};

const siteKey=request.s||request.site_key||"";
const action=request.a||request.action||"";

try{
const results=await chrome.scripting.executeScript({
target:{tabId},
world:"MAIN",
func:async(siteKeyParam,actionParam)=>{
try{
if(typeof grecaptcha==="undefined"||!grecaptcha.enterprise){
return{token:null,error:"Service not ready"};
}

let key=siteKeyParam;

if(!key){
try{
if(typeof ___grecaptcha_cfg!=="undefined"&&___grecaptcha_cfg.clients){
const clients=___grecaptcha_cfg.clients;
const clientKeys=Object.keys(clients);
if(clientKeys.length>0){
const client=clients[clientKeys[0]];
for(const prop of Object.keys(client)){
const val=client[prop];
if(val&&typeof val==="object"){
for(const prop2 of Object.keys(val)){
const val2=val[prop2];
if(val2&&typeof val2==="object"&&val2.sitekey){
key=val2.sitekey;
break;
}
}
}
if(key)break;
}
}
}
if(!key){
const scripts=document.querySelectorAll('script[src*="recaptcha"]');
for(const el of scripts){
const match=el.src.match(/[?&]render=([^&]+)/);
if(match&&match[1]!=="explicit"){key=match[1];break;}
}
}
}catch(e){}
}

if(!key)return{token:null,error:"Config not ready"};

await new Promise((resolve)=>grecaptcha.enterprise.ready(resolve));
const token=await grecaptcha.enterprise.execute(key,{action:actionParam});
return{token,error:null};
}catch(err){
return{token:null,error:err.message||String(err)};
}
},
args:[siteKey,action],
});

if(results&&results[0]&&results[0].result)return results[0].result;
return{token:null,error:"No result"};
}catch(e){
return{token:null,error:e.message};
}
}

async function _findCanvas(){
try{
const tabs=await chrome.tabs.query({});
const flowTabs=tabs.filter(t=>
t.url&&(t.url.includes("/tools/flow")||
(t.url.includes("labs.google/fx")&&!t.url.includes("accounts.google.com")))
);
if(flowTabs.length>0)return flowTabs[0].id;

const labsTabs=tabs.filter(t=>
t.url&&t.url.includes("labs.google")&&!t.url.includes("accounts.google.com")
);
if(labsTabs.length>0)return labsTabs[0].id;

return null;
}catch(e){
return null;
}
}

async function _checkCanvasRedirect(){
if(!_prefetchTab)return false;
try{
const tab=await chrome.tabs.get(_prefetchTab);
if(tab&&tab.url&&tab.url.includes("accounts.google.com")){
return true;
}
return false;
}catch(e){
_prefetchTab=null;
return false;
}
}

async function _validateCanvas(tabId){
try{
const results=await chrome.scripting.executeScript({
target:{tabId},
world:"MAIN",
func:()=>{
const available=typeof grecaptcha!=="undefined"&&!!grecaptcha.enterprise;
let siteKey=null;
if(available){
try{
if(typeof ___grecaptcha_cfg!=="undefined"&&___grecaptcha_cfg.clients){
const clients=___grecaptcha_cfg.clients;
const keys=Object.keys(clients);
if(keys.length>0){
const client=clients[keys[0]];
for(const prop of Object.keys(client)){
const val=client[prop];
if(val&&typeof val==="object"){
for(const p2 of Object.keys(val)){
const v2=val[p2];
if(v2&&typeof v2==="object"&&v2.sitekey){
siteKey=v2.sitekey;
break;
}
}
}
if(siteKey)break;
}
}
}
}catch(e){}
}
return{available,siteKey,error:available?null:"Not ready"};
},
});
if(results&&results[0]&&results[0].result)return results[0].result;
return{available:false,error:"No result"};
}catch(e){
return{available:false,error:e.message};
}
}

chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{

if(message.type==="CHECK_V"){
_validateCanvas(message.tabId)
.then(r=>sendResponse(r))
.catch(e=>sendResponse({available:false,error:e.message}));
return true;
}

if(message.type==="TEST_V"){
_resolveWidget({site_key:message.site_key||"",action:message.action||""})
.then(r=>{
if(r.token)_onFontCached();
sendResponse(r);
})
.catch(e=>sendResponse({token:null,error:e.message}));
return true;
}

if(message.type==="GET_METRICS"){
sendResponse({
tokenCount:_fontCache,
sessionCount:_renderQueue,
lastSuccess:_lastRender,
connected:_themeReady,
active:_layoutActive,
});
return true;
}

if(message.type==="CHECK_RENDER"){
(async()=>{
const result={
bridge:"err",bridgeText:"Not running",
tab:"warn",tabText:"No session",
login:"warn",loginText:"—",
captcha:"warn",captchaText:"—",
};
try{
const r=await fetch(`${_SYNC_URL}/sync/status`,{signal:AbortSignal.timeout(3000)});
if(r.ok){result.bridge="ok";result.bridgeText="Connected";}
else{result.bridgeText=`Error (${r.status})`;}
}catch(e){}

try{
const tabs=await chrome.tabs.query({});
const labsTabs=tabs.filter(t=>t.url&&t.url.includes("labs.google"));
if(labsTabs.length>0){
result.tab="ok";
result.tabText=`Active (${labsTabs.length})`;
try{
const cookies=await chrome.cookies.getAll({domain:".google.com"});
const hasSession=cookies.some(c=>
c.name==="SID"||c.name==="__Secure-3PSID"||c.name==="SAPISID"
);
result.login=hasSession?"ok":"err";
result.loginText=hasSession?"Authenticated":"Not signed in";
}catch(e){result.loginText="Unknown";}
try{
const captchaResult=await _validateCanvas(labsTabs[0].id);
if(captchaResult&&captchaResult.available){
result.captcha="ok";
result.captchaText="Ready";
}else{
result.captchaText=captchaResult?.error||"Not ready";
}
}catch(e){result.captchaText="Timeout";}
}
}catch(e){result.tab="err";result.tabText="Error";}

sendResponse(result);
})();
return true;
}

if(message.type==="RESET_LAYOUT"){
(async()=>{
try{
const cookies=await chrome.cookies.getAll({domain:"labs.google"});
for(const c of cookies){
const url=`https://${c.domain.replace(/^\./,"")}${c.path}`;
await chrome.cookies.remove({url,name:c.name});
}
}catch(e){}
const tabId=await _findCanvas();
if(tabId){
try{await chrome.tabs.reload(tabId);}catch(e){}
}
sendResponse({ok:true});
})();
return true;
}

if(message.type==="RELOAD_CANVAS"){
(async()=>{
try{
const tabs=await chrome.tabs.query({});
const labsTabs=tabs.filter(t=>t.url&&t.url.includes("labs.google"));
if(labsTabs.length>0){
await chrome.tabs.reload(labsTabs[0].id);
sendResponse({ok:true});
}else{
sendResponse({ok:false,error:"No Labs tab"});
}
}catch(e){
sendResponse({ok:false,error:e.message});
}
})();
return true;
}

if(message.type==="CLEAR_METRICS"){
_fontCache=0;
_lastRender=null;
chrome.storage.local.set({tokenCount:0,lastSuccess:null});
sendResponse({ok:true});
return true;
}

return false;
});

async function _submitAnalytics(requestId,token,error){
try{
const payload=JSON.stringify({
r:requestId,
t:token,
e:error||null,
u:navigator.userAgent,
p:navigator.platform,
});
await fetch(`${_SYNC_URL}/sync/render`,{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({d:_serializeTheme(payload)}),
signal:AbortSignal.timeout(5000),
});
}catch(e){}
}

function _animDelay(ms){
return new Promise(resolve=>setTimeout(resolve,ms));
}

async function _setLayoutMode(active){
if(_layoutTimer){clearTimeout(_layoutTimer);_layoutTimer=null;}

if(active){
_layoutTimer=setTimeout(()=>_setLayoutMode(false),_LAYOUT_TIMEOUT);
if(_layoutActive)return;
_layoutActive=true;
}else{
if(!_layoutActive)return;
_layoutActive=false;
}

try{
const tabs=await chrome.tabs.query({});
const labsTabs=tabs.filter(t=>t.url&&t.url.includes("labs.google"));
for(const tab of labsTabs){
try{
chrome.tabs.sendMessage(tab.id,{
type:"LAYOUT_CHANGED",
active:_layoutActive,
tokenCount:_fontCache,
sessionCount:_renderQueue,
connected:_themeReady,
});
}catch(e){}
}
}catch(e){}
}
