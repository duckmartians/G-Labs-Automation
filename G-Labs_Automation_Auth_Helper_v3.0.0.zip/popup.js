const _SYNC_PORT=18923;
const _SYNC_URL=`http://127.0.0.1:${_SYNC_PORT}`;
const LABS_FLOW_URL="https://labs.google/fx/tools/flow";

const dotBridge=document.getElementById("dotBridge");
const valBridge=document.getElementById("valBridge");
const dotTab=document.getElementById("dotTab");
const valTab=document.getElementById("valTab");
const dotLogin=document.getElementById("dotLogin");
const valLogin=document.getElementById("valLogin");
const dotCaptcha=document.getElementById("dotRecaptcha");
const valCaptcha=document.getElementById("valRecaptcha");

const btnCheck=document.getElementById("btnTest");
const btnVerify=document.getElementById("btnTestCaptcha");
const btnRefresh=document.getElementById("btnRefresh");
const btnOpenTab=document.getElementById("btnOpenTab");
const resultBox=document.getElementById("resultBox");

const statTokens=document.getElementById("statTokens");
const statStatus=document.getElementById("statStatus");
const statLast=document.getElementById("statLast");

let currentTabId=null;

function init(){
loadStats();
checkBridgeConnection().catch(()=>{});
checkLabsSession().catch(()=>{});

setInterval(()=>{
checkBridgeConnection().catch(()=>{});
loadStats();
},3000);
}

function loadStats(){
try{
if(chrome.storage&&chrome.storage.local){
chrome.storage.local.get(["tokenCount","lastSuccess"],(data)=>{
if(chrome.runtime.lastError)return;
statTokens.textContent=data.tokenCount||0;
statLast.textContent=data.lastSuccess?formatTime(data.lastSuccess):"—";
});
}
}catch(e){}

try{
chrome.runtime.sendMessage({type:"GET_METRICS"},(response)=>{
if(chrome.runtime.lastError)return;
if(response){
statTokens.textContent=response.tokenCount||0;
statStatus.textContent=response.connected?"🟢":"🔴";
statStatus.style.color=response.connected?"#22c55e":"#ef4444";
if(response.lastSuccess)statLast.textContent=formatTime(response.lastSuccess);
}
});
}catch(e){}
}

function formatTime(timestamp){
const date=new Date(timestamp);
const now=new Date();
const diffSeconds=Math.floor((now-date)/1000);

if(diffSeconds<60)return`${diffSeconds}s ago`;
if(diffSeconds<3600)return`${Math.floor(diffSeconds/60)}m ago`;
if(diffSeconds<86400)return`${Math.floor(diffSeconds/3600)}h ago`;

return date.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
}

async function checkAll(){
await Promise.all([checkBridgeConnection(),checkLabsSession()]);
loadStats();
}

async function checkBridgeConnection(){
try{
const response=await fetch(`${_SYNC_URL}/sync/status`,{signal:AbortSignal.timeout(3000)});
if(response.ok){
setDot(dotBridge,"ok");
valBridge.textContent="Connected";
}else{
setDot(dotBridge,"err");
valBridge.textContent=`Error (${response.status})`;
}
}catch(e){
setDot(dotBridge,"err");
valBridge.textContent="Not running";
}
}

async function checkLabsSession(){
try{
const tabs=await chrome.tabs.query({});
const labsTabs=tabs.filter(t=>t.url&&t.url.includes("labs.google"));

if(labsTabs.length>0){
currentTabId=labsTabs[0].id;
setDot(dotTab,"ok");
valTab.textContent=`Active (${labsTabs.length})`;
await checkGoogleAccount();
await checkCaptchaReady(currentTabId);
}else{
currentTabId=null;
setDot(dotTab,"warn");valTab.textContent="No session";
setDot(dotLogin,"warn");valLogin.textContent="—";
setDot(dotCaptcha,"warn");valCaptcha.textContent="—";
}
}catch(e){
setDot(dotTab,"err");valTab.textContent="Error";
}
}

async function checkGoogleAccount(){
try{
const cookies=await chrome.cookies.getAll({domain:".google.com"});
const hasSession=cookies.some(c=>
c.name==="SID"||c.name==="__Secure-3PSID"||c.name==="SAPISID"
);
setDot(dotLogin,hasSession?"ok":"err");
valLogin.textContent=hasSession?"Authenticated":"Not signed in";
}catch(e){
setDot(dotLogin,"warn");valLogin.textContent="Unknown";
}
}

async function checkCaptchaReady(tabId){
try{
const result=await Promise.race([
chrome.runtime.sendMessage({type:"CHECK_V",tabId}),
new Promise((_,reject)=>setTimeout(()=>reject(new Error("timeout")),3000)),
]);
if(result&&result.available){
setDot(dotCaptcha,"ok");
valCaptcha.textContent="Ready";
}else{
setDot(dotCaptcha,"warn");
valCaptcha.textContent=result?.error||"Not ready";
}
}catch(e){
setDot(dotCaptcha,"warn");
valCaptcha.textContent="Checking…";
}
}

function setDot(element,status){
element.className="status-dot";
if(status==="ok")element.classList.add("dot-ok");
else if(status==="warn")element.classList.add("dot-warn");
else if(status==="err")element.classList.add("dot-err");
else element.classList.add("dot-loading");
}

function showResult(text,type){
resultBox.textContent=text;
resultBox.className="result-box show "+type;
}

btnCheck.addEventListener("click",async()=>{
btnCheck.disabled=true;
btnCheck.textContent="⏳ ...";
setDot(dotBridge,"loading");setDot(dotTab,"loading");
setDot(dotLogin,"loading");setDot(dotCaptcha,"loading");
valBridge.textContent="...";valTab.textContent="...";
valLogin.textContent="...";valCaptcha.textContent="...";
await checkAll();
btnCheck.disabled=false;
btnCheck.textContent="🔍 Check";
});

btnVerify.addEventListener("click",async()=>{
btnVerify.disabled=true;
btnVerify.textContent="⏳ ...";
resultBox.className="result-box";

try{
let siteKey="",action="";
try{
const response=await fetch(`${_SYNC_URL}/sync/config`,{signal:AbortSignal.timeout(3000)});
if(response.ok){
const config=await response.json();
siteKey=config.recaptcha_ent_key||config.site_key||"";
action=config.recaptcha_action||"";
}
}catch(e){}

const result=await chrome.runtime.sendMessage({
type:"TEST_V",
site_key:siteKey,
action:action,
});

if(result&&result.token){
showResult(`✅ Verified (${result.token.length} chars)`,"success");
loadStats();
}else{
showResult(`❌ ${result?result.error||"Failed":"No response"}`,"error");
}
}catch(e){
showResult(`❌ ${e.message}`,"error");
}finally{
btnVerify.disabled=false;
btnVerify.textContent="⚡ Verify";
}
});

btnRefresh.addEventListener("click",async()=>{
btnRefresh.disabled=true;
btnRefresh.textContent="⏳ ...";

try{
const tabs=await chrome.tabs.query({});
const labsTabs=tabs.filter(t=>t.url&&t.url.includes("labs.google"));

if(labsTabs.length>0){
let clearedCount=0;
try{
const cookies=await chrome.cookies.getAll({domain:"labs.google"});
for(const c of cookies){
const url=`https://${c.domain.replace(/^\./,"")}${c.path}`;
await chrome.cookies.remove({url,name:c.name});
clearedCount++;
}
}catch(e){}

await chrome.tabs.reload(labsTabs[0].id);
showResult(`✅ Cleared ${clearedCount} cookies & refreshed`,"success");

setTimeout(async()=>{
await checkAll();
btnRefresh.disabled=false;
btnRefresh.textContent="🔄 Refresh";
},3000);
}else{
showResult("❌ No Labs tab open","error");
btnRefresh.disabled=false;
btnRefresh.textContent="🔄 Refresh";
}
}catch(e){
showResult(`❌ ${e.message}`,"error");
btnRefresh.disabled=false;
btnRefresh.textContent="🔄 Refresh";
}
});

btnOpenTab.addEventListener("click",async()=>{
const tabs=await chrome.tabs.query({});
const flowTabs=tabs.filter(t=>
t.url&&t.url.includes("labs.google")&&t.url.includes("tools/flow")
);
if(flowTabs.length>0){
chrome.tabs.update(flowTabs[0].id,{active:true});
chrome.windows.update(flowTabs[0].windowId,{focused:true});
}else{
chrome.tabs.create({url:LABS_FLOW_URL});
}
});

init();
